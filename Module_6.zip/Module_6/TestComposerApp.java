import java.util.Scanner;

public class TestComposerApp {

    private static MemComposerDao composerDao = new MemComposerDao();

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int option = 0;
        System.out.println("  Welcome to the Composer App");
        while (option != 4) {
            System.out.println("\n  MENU OPTIONS");
            System.out.println("    1. View Composers");
            System.out.println("    2. Find Composer");
            System.out.println("    3. Add Composer");
            System.out.println("    4. Exit");
            System.out.print("\n  Please choose an option: ");
            option = input.nextInt();
            input.nextLine(); // consume the newline character

            switch (option) {
                case 1:
                    listComposers();
                    break;
                case 2:
                    findComposerById(input);
                    break;
                case 3:
                    addNewComposer(input);
                    break;
                case 4:
                    System.out.println("Goodbye!");
                    break;
                default:
                    System.out.println("Invalid option, please try again.");
                    break;
            }
        }
    }

    private static void listComposers() {
        System.out.println("\n  --DISPLAYING COMPOSERS--");
        for (Composer composer : composerDao.findAll()) {
            System.out.println(composer +"\n");
        }
    }

    private static void findComposerById(Scanner input) {
        System.out.print("\n  Enter an id: ");
        int id = input.nextInt();
        Composer composer = composerDao.findBy(id);
        if (composer == null) {
            System.out.println("Composer not found.");
        } else {
        	System.out.println("\n  --DISPLAYING COMPOSERS--");
            System.out.println(composer);
        }
    }

    private static void addNewComposer(Scanner input) {
    	System.out.print("\n  Enter an id: ");
        String id = input.nextLine();
        System.out.print("  Enter a name: ");
        String name = input.nextLine();
        System.out.print("  Enter a genre: ");
        String genre = input.nextLine();
        Composer newComposer = new Composer(Integer.parseInt(id), name, genre);
        composerDao.insert(newComposer);
    }
}
